#include <iostream>
#include <cstring>
#include "Account.h"
//#include "SavingAcc.h"
//#include "CurrentAcc.h"
using namespace std;

class AccountService {
    static Account arr[100];
    static int count;
    
    public:
        static Account acceptData() {
            char first[100], last[100], emailid[100];
            long mobile;
            cout << "Enter First Name : ";
            cin >> first;
            cout << "Enter Last Name : ";
            cin >> last;
            cout << "Enter Mobile No. : ";
            cin >> mobile;
            cout << "Enter Email ID : ";
            cin >> emailid;
            return Account(first, last, mobile, emailid);
        }
        
        static void addAccount(Account &ob) {
            if(count<100){
                //cout << "............" <<ob.getFname() << endl;
                arr[count].setFname(ob.getFname());
                arr[count].setLname(ob.getLname());
                arr[count].setEmail(ob.getEmail());
                arr[count].setMobile(ob.getMobile());
                arr[count].setId(ob.getId());
                
                cout<<"Account added at "<<count<< " position" << endl;
                count++;
            }else{
                cout<<"List is full";
            }
        }
        
        static void displayAll() {
            for (int i = 0; i < count; i++) {
                arr[i].display();
                cout << "------------------" << endl;
            }
        }
        
        static Account* searchByAccount(const char* inp) {
            for (int i = 0; i < count; i++) {
                if (strcmp(arr[i].getId(), inp) == 0) {
                    return &arr[i];
                }
            }
            return nullptr;
        }
};
