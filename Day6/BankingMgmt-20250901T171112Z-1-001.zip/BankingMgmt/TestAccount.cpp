#include <iostream>
#include "SavingAcc.h"
#include "CurrentAcc.h"
#include "AccountService.cpp"
using namespace std;

Account AccountService::arr[100];
int AccountService::count = 0;

int main() {
    /*
    Account ob1("Alan", "Walker", 9876567879, "alanwalker@gmail.com");
    ob1.display();

    SavingAcc ob2("Ken", "Thomson", 4851236597, "kenthomson@gmail.com", 7896558458457854);
    ob2.display();

    CurrentAcc ob3("Barr", "Allen", 6325741895, "barryallen@gmail.com", 84000);
    ob3.display();
    return 0;
    */

    int choice;
    
    do {
        cout << "\n--- Account Management ---\n";
    	cout << "1. Add new account\n";
   	cout << "2. Display All Accounts\n";
   	cout << "3. Search by account number\n";
   	cout << "4. Search by Name\n";
   	cout << "5. Sort Accounts by balance\n";
   	cout << "6. Display All Saving Account\n";
  	cout << "7. Display All Current Account\n";
  	cout << "8. Exit\n";
  	cout << "Enter your Choice : ";
  	cin >> choice;
    
        switch(choice){
            case 1: {
                Account ob = AccountService::acceptData();
                AccountService::addAccount(ob);
                break;
            }
            case 2:
                AccountService::displayAll();
                break;
            case 3: {
                char inp[7];
                cin >> inp;
                Account* ob1 = AccountService::searchByAccount(inp);
                if (ob1)
                    ob1->display();
                else
                    cout << "not Found" <<endl;
                break;
            }
        }
    } while(choice != 9);
}
