package org.cdac;


public class EmployeeSorter {

//	EmployeeEnums field;
//	
//	public EmployeeSorter(EmployeeEnums field) {
//		this.field = field;
//	}
//	
//	@Override
//	public int compare(Employee emp1, Employee emp2) {
//		switch(field) {
//		
//		case NAME: return emp1.getName().compareToIgnoreCase(emp2.getName());
//		
//		case ADDRESS: return emp1.getAddress().compareToIgnoreCase(emp2.getAddress());
//		
//		case AGE: return emp1.getAge() - emp2.getAge();
//		
//		case GENDER: return emp1.getGender() - emp2.getGender();
//		 
//		case BASICSALARY: return (int) (emp1.getBasicSalary() - emp2.getBasicSalary());
//		
//		case TOTALSALARY: return (int) (emp1.calculateSalary() - emp2.calculateSalary());
//		
//		case DESIGNATION: return emp1.getDesignation().compareToIgnoreCase(emp2.getDesignation());
//		
//		default: return 0;
//		}
//	}
//	
//	public static LinkedList<Employee> sortByType(LinkedList<Employee> list) {
//		LinkedList<Employee> tempList = new LinkedList<>();
//		for (Employee emp = list.getFirst(); emp != null; emp = list.getNext()) {
//			if (emp instanceof Manager)
//				tempList.add(emp);
//		}
//		for (Employee emp = list.getFirst(); emp != null; emp = list.getNext()) {
//			if (emp instanceof Engineer)
//				tempList.add(emp);
//		}
//		for (Employee emp = list.getFirst(); emp != null; emp = list.getNext()) {
//			if (emp instanceof SalesPerson)
//				tempList.add(emp);
//		}
//		
//		return tempList;
//	}
	
}
