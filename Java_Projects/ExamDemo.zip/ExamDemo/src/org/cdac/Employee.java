package org.cdac;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

public class Employee implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5213363532684516559L;
	private int id;
	private String name;
	private Department dept;
	private LocalDate joiningDate;
	
	/**
	 * @param id
	 * @param name
	 * @param dept
	 * @param joiningDate
	 */
	public Employee(int id, String name, Department dept, LocalDate joiningDate) {
		super();
		this.id = id;
		this.name = name;
		this.dept = dept;
		this.joiningDate = joiningDate;
	}
	
	// getter for all field
	public int getId() { return id; }
	
	public String getName() { return name; }
	
	public Department getDept() { return dept; }

	public LocalDate getJoiningDate() { return joiningDate; }
	
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", dept=" + dept + ", joiningDate=" + joiningDate + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Employee))
			return false;
		Employee other = (Employee) obj;
		return dept == other.dept && id == other.id && Objects.equals(joiningDate, other.joiningDate)
				&& Objects.equals(name, other.name);
	}

	@Override
	public int hashCode() {
		return Integer.hashCode(id);
	}
	
}
