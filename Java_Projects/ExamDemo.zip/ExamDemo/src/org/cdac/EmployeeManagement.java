package org.cdac;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class EmployeeManagement {

	List<Employee> list = new LinkedList<>();

	
	public void addEmployee(int id, String name, String depts, String dates) throws InvalidInputException {
		
		Department dept = Department.valueOf(depts.toUpperCase());
		
		LocalDate date = LocalDate.parse(dates);
		
		list.add(new Employee(id, name, dept, date));

	}

	// Display All Employees
	public void displayAll() {
		
		list.forEach(System.out::println);
	}
	
	public List<Employee> deptWiseEmployee() {
		
		list.stream().filter(a -> a.getName().charAt(0)!='A').forEach(System.out::println);
		
		List<Employee> deptList = new LinkedList<>();
		
		Map<Department, List<Employee>> map = list.stream().collect(Collectors.groupingBy(Employee::getDept));

		map.values().forEach(deptList::addAll);
		
		return deptList;
	}

	
	
	public HashMap<Department, Integer> deptWiseCount() {
		
		Map<Department, Integer> map = new HashMap<>();
		
		list.forEach(emp -> map.merge(emp.getDept(), 1, Integer::sum));
		
		return (HashMap<Department, Integer>) map;
	}

	
	
	public void sortByDate() {
		list.sort((a, b) -> a.getJoiningDate().compareTo(b.getJoiningDate()));
	}

	
	
	@SuppressWarnings("unchecked")
	public void loadFile(String fileName) throws FileNotFoundException, IOException, ClassNotFoundException {
		File file = new File(fileName);
		if (!file.exists())
			return;

		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
			list = (LinkedList<Employee>) ois.readObject();
		}
	}

	
	
	public void saveFile(String fileName) throws FileNotFoundException, IOException {
		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
			oos.writeObject(list);
		}
	}

}
