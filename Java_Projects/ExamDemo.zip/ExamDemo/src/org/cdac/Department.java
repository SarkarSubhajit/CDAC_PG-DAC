package org.cdac;

//import java.util.NoSuchElementException;

public enum Department {

	ENGINEER,
	SALES,
	MANAGER,
	HR,
	IT,
	FINANCE,
	MARKETING,
	SCIENTIST;
	
}
