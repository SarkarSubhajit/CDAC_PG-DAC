#include "ContractEmp.h"
#include<iostream>
using namespace std;

ContractEmp::ContractEmp():hours(0.0),charges(0.0){
//cout<<"in default constructor of SalariedEmp" <<endl;
  //sal=0.0
  //bonus=0.0;
}

ContractEmp::ContractEmp(int eno,const char* nm,const char *dt,const char* ds,double rate, double pay):Employee(eno,nm,dt,ds){
//cout<<"in parametrised constructor of SalariedEmp" <<endl;
  hours = rate;
  charges = pay;
}
ContractEmp::~ContractEmp(){
   //cout<<"in salariedemp destructor" <<endl;
}

void ContractEmp::display(){
     Employee::display();
     cout<<"Hourly rate: "<<hours;
     cout<<"Charges: " <<charges<<endl;
}

