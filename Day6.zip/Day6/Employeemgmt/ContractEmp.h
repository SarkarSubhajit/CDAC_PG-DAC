#include "Employee.h"

class ContractEmp:public Employee{
   private:
      double hours;
      double charges;
      
   public:
      ContractEmp();
      ContractEmp(int eno,const char* nm,const char *dt,const char* ds,double rate, double pay);
      ~ContractEmp();
      void setHours(double rate);
      void setCharges(double pay);
      double getHours();
      double getCharges();
      void display();
};
